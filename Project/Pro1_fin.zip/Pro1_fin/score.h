/* 
 * File:   structs.h
 * Author: RR
 *
 * Created on April 12, 2015, 11:56 PM
 */

#ifndef STRUCTS_H
#define	STRUCTS_H

struct Score{
   int numb;
   char word[5];
   char corrc[5];
   char guess[10];
   int score;
};

#endif	/* STRUCTS_H */


